Dane w folderze : Dane_PR2
Wyniki w floderze: Debug

Generated: D01062017H2159PM
Compatible with cpp versions: cpp0x / cpp11
Work for: clang++ / gcc
Additiona Compiler Options: -g;-O0;-std=c++11;-Wall
Main cpp file: main.cpp
Executable file: Debug / Szyfr_Cezara.exe
Project Name: Szyfr_Cezara
Used IDE: CodeLite v10.0.3 